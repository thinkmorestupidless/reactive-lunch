the-actor-system

## Exercise 1 > The Actor System

Shows the simplest possible Actor System; A single Actor which receives a single type of message.
