actor-supervision

## Exercise 3 - Actor Supervision

This is a first exercise. Put your code in this project and
create new projects to add subsequent exercises
