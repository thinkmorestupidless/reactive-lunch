actor-supervision

## Exercise 3 - Actor Supervision

Actors supervise their children automatically. If an Actor encounters an unexpected error (a failure scenario) then a message is sent to its supervising Actor and that Actor decides what to do.
