the-actor-lifecycle

## Exercise 2 - The Actor Lifecycle

There are a couple of 'lifecycle' methods for an Actor. These methods are invoked by the ActorSystem when Actors are started and stopped. This excercise demonstrates how and when these methods are invoked during each of the different ways of stopping an Actor.
