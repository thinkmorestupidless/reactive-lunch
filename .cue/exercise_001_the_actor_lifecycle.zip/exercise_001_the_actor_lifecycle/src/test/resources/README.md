the-actor-lifecycle

## Exercise 2 - The Actor Lifecycle

This is a first exercise. Put your code in this project and
create new projects to add subsequent exercises
